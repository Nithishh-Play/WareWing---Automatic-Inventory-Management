// src/main/java/com/example/demo/service/PurchaseOrderService.java
package com.example.demo.service;

import com.example.demo.dto.PurchaseOrderDto;
import com.example.demo.dto.PurchaseOrderLineDto;
import com.example.demo.entity.PurchaseOrder;
import com.example.demo.entity.StockItem;
import com.example.demo.entity.Supplier;
import com.example.demo.exception.BusinessValidationException;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.repository.PurchaseOrderRepository;
import com.example.demo.repository.StockItemRepository;
import com.example.demo.repository.SupplierRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
public class PurchaseOrderService {

    private final PurchaseOrderRepository purchaseOrderRepository;
    private final SupplierRepository supplierRepository;
    private final StockItemRepository stockItemRepository;
    private final StockItemService stockItemService;
    private final SupplierService supplierService;

    public PurchaseOrderService(PurchaseOrderRepository purchaseOrderRepository,
                                 SupplierRepository supplierRepository,
                                 StockItemRepository stockItemRepository,
                                 StockItemService stockItemService,
                                 SupplierService supplierService) {
        this.purchaseOrderRepository = purchaseOrderRepository;
        this.supplierRepository = supplierRepository;
        this.stockItemRepository = stockItemRepository;
        this.stockItemService = stockItemService;
        this.supplierService = supplierService;
    }

    public List<PurchaseOrder> getAllOrders() {
        return purchaseOrderRepository.findAll();
    }

    public PurchaseOrder createDraftPo(PurchaseOrderDto dto, String username) {
        Supplier supplier = supplierRepository.findById(dto.getSupplierId())
                .orElseThrow(() -> new ResourceNotFoundException("Supplier not found"));

        PurchaseOrder po = new PurchaseOrder();
        po.setPoNumber("PO-" + UUID.randomUUID().toString().substring(0, 8));
        po.setSupplier(supplier);
        po.setOrderedBy(username);
        po.setStatus(PurchaseOrder.OrderStatus.DRAFT);
        po.setOrderDate(LocalDateTime.now());
        po.setExpectedDelivery(dto.getExpectedDelivery());

        BigDecimal total = BigDecimal.ZERO;
        List<PurchaseOrder.PurchaseOrderLine> lines = new ArrayList<>();

        for (PurchaseOrderLineDto lineDto : dto.getLines()) {
            StockItem item = stockItemRepository.findById(lineDto.getStockItemId())
                    .orElseThrow(() -> new ResourceNotFoundException("Stock item not found"));

            PurchaseOrder.PurchaseOrderLine line = new PurchaseOrder.PurchaseOrderLine();
            line.setStockItem(item);
            line.setOrderedQuantity(lineDto.getOrderedQuantity());
            line.setReceivedQuantity(0);
            line.setUnitPrice(item.getUnitPrice());
            lines.add(line);

            total = total.add(item.getUnitPrice().multiply(BigDecimal.valueOf(lineDto.getOrderedQuantity())));
        }

        po.setLines(lines);
        po.setTotalAmount(total);

        return purchaseOrderRepository.save(po);
    }

    public PurchaseOrder submitPo(Long id) {
        PurchaseOrder po = purchaseOrderRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Purchase order not found"));

        if (po.getStatus() != PurchaseOrder.OrderStatus.DRAFT) {
            throw new BusinessValidationException("Only DRAFT POs can be submitted");
        }
        if (po.getSupplier().getStatus() != Supplier.SupplierStatus.ACTIVE) {
            throw new BusinessValidationException("Cannot submit PO for inactive supplier");
        }

        po.setStatus(PurchaseOrder.OrderStatus.SUBMITTED);
        return purchaseOrderRepository.save(po);
    }

    public PurchaseOrder approvePo(Long id) {
        PurchaseOrder po = purchaseOrderRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Purchase order not found"));

        if (po.getStatus() != PurchaseOrder.OrderStatus.SUBMITTED) {
            throw new BusinessValidationException("Only SUBMITTED POs can be approved");
        }

        po.setStatus(PurchaseOrder.OrderStatus.APPROVED);
        return purchaseOrderRepository.save(po);
    }

    @Transactional(rollbackFor = Exception.class)
    public PurchaseOrder receivePo(Long id, String username) {
        PurchaseOrder po = purchaseOrderRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Purchase order not found"));

        if (po.getStatus() != PurchaseOrder.OrderStatus.APPROVED) {
            throw new BusinessValidationException("Only APPROVED POs can be received");
        }

        for (PurchaseOrder.PurchaseOrderLine line : po.getLines()) {
            line.setReceivedQuantity(line.getOrderedQuantity());
            stockItemService.updateStockLevel(
                    line.getStockItem().getId(),
                    line.getOrderedQuantity(),
                    "INBOUND",
                    po.getId(),
                    username
            );
        }

        po.setStatus(PurchaseOrder.OrderStatus.RECEIVED);
        purchaseOrderRepository.save(po);

        supplierService.recalculateSupplierReliability(po.getSupplier().getId());

        return po;
    }

    public void deleteDraftPo(Long id) {
        PurchaseOrder po = purchaseOrderRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Purchase order not found"));

        if (po.getStatus() != PurchaseOrder.OrderStatus.DRAFT) {
            throw new BusinessValidationException("Only DRAFT POs can be deleted");
        }

        purchaseOrderRepository.deleteById(id);
    }
}