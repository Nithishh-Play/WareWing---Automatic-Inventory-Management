// src/main/java/com/example/demo/repository/SupplierRepository.java
package com.example.demo.repository;

import com.example.demo.entity.Supplier;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SupplierRepository extends JpaRepository<Supplier, Long> {
    long countByStatus(Supplier.SupplierStatus status);
}