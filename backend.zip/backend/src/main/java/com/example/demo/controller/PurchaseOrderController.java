// src/main/java/com/example/demo/controller/PurchaseOrderController.java
package com.example.demo.controller;

import com.example.demo.dto.PurchaseOrderDto;
import com.example.demo.entity.PurchaseOrder;
import com.example.demo.service.PurchaseOrderService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/purchase-orders")
public class PurchaseOrderController {

    private final PurchaseOrderService purchaseOrderService;

    public PurchaseOrderController(PurchaseOrderService purchaseOrderService) {
        this.purchaseOrderService = purchaseOrderService;
    }

    @GetMapping("/all")
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER','VIEWER')")
    public ResponseEntity<List<PurchaseOrder>> getAllOrders() {
        return ResponseEntity.ok(purchaseOrderService.getAllOrders());
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER')")
    public ResponseEntity<PurchaseOrder> createOrder(@Valid @RequestBody PurchaseOrderDto dto,
                                                       Authentication authentication) {
        return ResponseEntity.ok(purchaseOrderService.createDraftPo(dto, authentication.getName()));
    }

    @PutMapping("/{id}/submit")
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER')")
    public ResponseEntity<PurchaseOrder> submit(@PathVariable Long id) {
        return ResponseEntity.ok(purchaseOrderService.submitPo(id));
    }

    @PutMapping("/{id}/approve")
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER')")
    public ResponseEntity<PurchaseOrder> approve(@PathVariable Long id) {
        return ResponseEntity.ok(purchaseOrderService.approvePo(id));
    }

    @PutMapping("/{id}/receive")
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER')")
    public ResponseEntity<PurchaseOrder> receive(@PathVariable Long id, Authentication authentication) {
        return ResponseEntity.ok(purchaseOrderService.receivePo(id, authentication.getName()));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER')")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        purchaseOrderService.deleteDraftPo(id);
        return ResponseEntity.ok().build();
    }
}