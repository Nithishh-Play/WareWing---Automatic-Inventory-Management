// src/main/java/com/example/demo/service/StockMovementService.java
package com.example.demo.service;

import com.example.demo.dto.StockMovementDto;
import com.example.demo.entity.StockItem;
import com.example.demo.entity.StockMovement;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.repository.StockItemRepository;
import com.example.demo.repository.StockMovementRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class StockMovementService {

    private final StockMovementRepository stockMovementRepository;
    private final StockItemRepository stockItemRepository;

    public StockMovementService(StockMovementRepository stockMovementRepository, StockItemRepository stockItemRepository) {
        this.stockMovementRepository = stockMovementRepository;
        this.stockItemRepository = stockItemRepository;
    }

    public List<StockMovement> getAllMovements() {
        return stockMovementRepository.findAllWithStockItem();
    }

    public StockMovement recordMovement(StockMovementDto dto, String performedBy) {
        StockItem item = stockItemRepository.findById(dto.getStockItemId())
                .orElseThrow(() -> new ResourceNotFoundException("Stock item not found"));

        StockMovement movement = new StockMovement();
        movement.setStockItem(item);
        movement.setMovementType(StockMovement.MovementType.valueOf(dto.getMovementType()));
        movement.setQuantityDelta(dto.getQuantityDelta());
        movement.setPreviousQuantity(item.getCurrentQuantity());
        movement.setNewQuantity(item.getCurrentQuantity() + dto.getQuantityDelta());
        movement.setReferencePoId(dto.getReferencePoId());
        movement.setPerformedBy(performedBy);
        movement.setMovementDate(LocalDateTime.now());
        movement.setNotes(dto.getNotes());

        return stockMovementRepository.save(movement);
    }

    public void deleteMovementsByItemId(Long itemId) {
        stockMovementRepository.deleteByStockItem_Id(itemId);
    }
}