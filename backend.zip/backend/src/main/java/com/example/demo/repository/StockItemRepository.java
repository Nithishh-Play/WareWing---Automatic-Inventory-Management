// src/main/java/com/example/demo/repository/StockItemRepository.java
package com.example.demo.repository;

import com.example.demo.entity.StockItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface StockItemRepository extends JpaRepository<StockItem, Long> {

    Optional<StockItem> findBySku(String sku);

    List<StockItem> findByCurrentQuantityLessThan(Integer threshold);

    @Query("SELECT COUNT(s) FROM StockItem s WHERE s.currentQuantity <= s.minimumThreshold")
    long countLowStockItems();
}