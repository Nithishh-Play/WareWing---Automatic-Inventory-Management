// src/main/java/com/example/demo/controller/StockMovementController.java
package com.example.demo.controller;

import com.example.demo.dto.StockMovementDto;
import com.example.demo.entity.StockMovement;
import com.example.demo.service.StockItemService;
import com.example.demo.service.StockMovementService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/stock-movements")
public class StockMovementController {

    private final StockMovementService stockMovementService;
    private final StockItemService stockItemService;

    public StockMovementController(StockMovementService stockMovementService, StockItemService stockItemService) {
        this.stockMovementService = stockMovementService;
        this.stockItemService = stockItemService;
    }

    @GetMapping("/all")
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER','VIEWER')")
    public ResponseEntity<List<StockMovement>> getAllMovements() {
        return ResponseEntity.ok(stockMovementService.getAllMovements());
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER')")
    public ResponseEntity<StockMovement> recordMovement(@Valid @RequestBody StockMovementDto dto,
                                                          Authentication authentication) {
        StockMovement movement = stockItemService.updateStockLevel(
                dto.getStockItemId(),
                dto.getQuantityDelta(),
                dto.getMovementType(),
                dto.getReferencePoId(),
                authentication.getName()
        );
        return ResponseEntity.ok(movement);
    }
}