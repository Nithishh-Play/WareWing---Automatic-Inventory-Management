// // src/main/java/com/example/demo/dto/AuthRequestDto.java
// package com.example.demo.dto;

// import jakarta.validation.constraints.NotBlank;

// public class AuthRequestDto {

//     @NotBlank(message = "Username is required")
//     private String username;

//     @NotBlank(message = "Password is required")
//     private String password;

//     public String getUsername() {
//         return username;
//     }

//     public void setUsername(String username) {
//         this.username = username;
//     }

//     public String getPassword() {
//         return password;
//     }

//     public void setPassword(String password) {
//         this.password = password;
//     }
// }
// src/main/java/com/example/demo/dto/AuthRequestDto.java
package com.example.demo.dto;

import jakarta.validation.constraints.NotBlank;

public class AuthRequestDto {

    @NotBlank(message = "Username is required")
    private String username;

    @NotBlank(message = "Password is required")
    private String password;

    private String role;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
}