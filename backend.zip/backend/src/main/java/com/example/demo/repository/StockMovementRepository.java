// src/main/java/com/example/demo/repository/StockMovementRepository.java
package com.example.demo.repository;

import com.example.demo.entity.StockMovement;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface StockMovementRepository extends JpaRepository<StockMovement, Long> {

    @Query("SELECT sm FROM StockMovement sm JOIN FETCH sm.stockItem ORDER BY sm.movementDate DESC")
    List<StockMovement> findAllWithStockItem();

    List<StockMovement> findByStockItem_IdOrderByMovementDateDesc(Long itemId);

    @Modifying
    @Transactional
    void deleteByStockItem_Id(Long itemId);
}