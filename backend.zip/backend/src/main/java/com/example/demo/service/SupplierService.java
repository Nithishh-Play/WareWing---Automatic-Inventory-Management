// src/main/java/com/example/demo/service/SupplierService.java
package com.example.demo.service;

import com.example.demo.dto.SupplierDto;
import com.example.demo.entity.Supplier;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.repository.PurchaseOrderRepository;
import com.example.demo.repository.SupplierRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SupplierService {

    private final SupplierRepository supplierRepository;
    private final PurchaseOrderRepository purchaseOrderRepository;

    public SupplierService(SupplierRepository supplierRepository, PurchaseOrderRepository purchaseOrderRepository) {
        this.supplierRepository = supplierRepository;
        this.purchaseOrderRepository = purchaseOrderRepository;
    }

    public List<Supplier> getAllSuppliers() {
        return supplierRepository.findAll();
    }

    public Supplier createSupplier(SupplierDto dto) {
        Supplier supplier = new Supplier();
        supplier.setName(dto.getName());
        supplier.setContactEmail(dto.getContactEmail());
        supplier.setPhone(dto.getPhone());
        supplier.setLeadTimeDays(dto.getLeadTimeDays());
        if (dto.getStatus() != null) {
            supplier.setStatus(Supplier.SupplierStatus.valueOf(dto.getStatus()));
        }
        return supplierRepository.save(supplier);
    }

    public Supplier updateSupplier(Long id, SupplierDto dto) {
        Supplier supplier = supplierRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Supplier not found"));
        supplier.setName(dto.getName());
        supplier.setContactEmail(dto.getContactEmail());
        supplier.setPhone(dto.getPhone());
        supplier.setLeadTimeDays(dto.getLeadTimeDays());
        if (dto.getStatus() != null) {
            supplier.setStatus(Supplier.SupplierStatus.valueOf(dto.getStatus()));
        }
        return supplierRepository.save(supplier);
    }

    public void deleteSupplier(Long id) {
        purchaseOrderRepository.deleteLinesBySupplierId(id);
        purchaseOrderRepository.deleteBySupplierId(id);
        supplierRepository.deleteById(id);
    }

    public void recalculateSupplierReliability(Long supplierId) {
        Supplier supplier = supplierRepository.findById(supplierId)
                .orElseThrow(() -> new ResourceNotFoundException("Supplier not found"));
        supplier.setReliabilityScore(95);
        supplierRepository.save(supplier);
    }
}