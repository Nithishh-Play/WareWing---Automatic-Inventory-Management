// src/main/java/com/example/demo/config/DataSeeder.java
package com.example.demo.config;

import com.example.demo.entity.SystemUser;
import com.example.demo.repository.SystemUserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class DataSeeder implements CommandLineRunner {

    private final SystemUserRepository systemUserRepository;
    private final PasswordEncoder passwordEncoder;

    public DataSeeder(SystemUserRepository systemUserRepository, PasswordEncoder passwordEncoder) {
        this.systemUserRepository = systemUserRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) {
        seedUser("admin", "admin123", "ADMIN");
        seedUser("manager", "manager123", "MANAGER");
        seedUser("viewer", "viewer123", "VIEWER");
    }

    private void seedUser(String username, String rawPassword, String role) {
        if (systemUserRepository.findByUsername(username).isEmpty()) {
            SystemUser user = new SystemUser(username, passwordEncoder.encode(rawPassword), role);
            systemUserRepository.save(user);
        }
    }
}