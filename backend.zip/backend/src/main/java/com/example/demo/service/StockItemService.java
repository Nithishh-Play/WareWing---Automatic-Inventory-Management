// src/main/java/com/example/demo/service/StockItemService.java
package com.example.demo.service;

import com.example.demo.dto.DashboardDto;
import com.example.demo.dto.StockItemDto;
import com.example.demo.dto.StockMovementDto;
import com.example.demo.entity.PurchaseOrder;
import com.example.demo.entity.StockItem;
import com.example.demo.entity.StockMovement;
import com.example.demo.entity.Supplier;
import com.example.demo.exception.BusinessValidationException;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.repository.PurchaseOrderRepository;
import com.example.demo.repository.StockItemRepository;
import com.example.demo.repository.SupplierRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class StockItemService {

    private final StockItemRepository stockItemRepository;
    private final StockMovementService stockMovementService;
    private final SupplierRepository supplierRepository;
    private final PurchaseOrderRepository purchaseOrderRepository;

    public StockItemService(StockItemRepository stockItemRepository,
                             StockMovementService stockMovementService,
                             SupplierRepository supplierRepository,
                             PurchaseOrderRepository purchaseOrderRepository) {
        this.stockItemRepository = stockItemRepository;
        this.stockMovementService = stockMovementService;
        this.supplierRepository = supplierRepository;
        this.purchaseOrderRepository = purchaseOrderRepository;
    }

    public List<StockItem> getAllItems() {
        return stockItemRepository.findAll();
    }

    public StockItem createItem(StockItemDto dto) {
        StockItem item = new StockItem();
        item.setSku(dto.getSku());
        item.setName(dto.getName());
        item.setCategory(dto.getCategory());
        item.setCurrentQuantity(dto.getCurrentQuantity() != null ? dto.getCurrentQuantity() : 0);
        item.setUnit(dto.getUnit() != null ? dto.getUnit() : "PCS");
        item.setMinimumThreshold(dto.getMinimumThreshold());
        item.setReorderQuantity(dto.getReorderQuantity());
        item.setUnitPrice(dto.getUnitPrice());
        item.setPreferredSupplierId(dto.getPreferredSupplierId());
        item.setAutoReorderEnabled(dto.getAutoReorderEnabled() != null ? dto.getAutoReorderEnabled() : true);
        if (dto.getStatus() != null) {
            item.setStatus(StockItem.ItemStatus.valueOf(dto.getStatus()));
        }
        return stockItemRepository.save(item);
    }

    public StockItem updateItem(Long id, StockItemDto dto) {
        StockItem item = stockItemRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Stock item not found"));
        item.setSku(dto.getSku());
        item.setName(dto.getName());
        item.setCategory(dto.getCategory());
        item.setCurrentQuantity(dto.getCurrentQuantity());
        item.setUnit(dto.getUnit());
        item.setMinimumThreshold(dto.getMinimumThreshold());
        item.setReorderQuantity(dto.getReorderQuantity());
        item.setUnitPrice(dto.getUnitPrice());
        item.setPreferredSupplierId(dto.getPreferredSupplierId());
        item.setAutoReorderEnabled(dto.getAutoReorderEnabled());
        if (dto.getStatus() != null) {
            item.setStatus(StockItem.ItemStatus.valueOf(dto.getStatus()));
        }
        return stockItemRepository.save(item);
    }

    public StockMovement updateStockLevel(Long id, int delta, String movementType, Long referencePoId, String performedBy) {
        StockItem item = stockItemRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Stock item not found"));

        int newQty = item.getCurrentQuantity() + delta;
        if (newQty < 0) {
            throw new BusinessValidationException(
                    "Insufficient stock level for " + item.getName() + " (Available: " + item.getCurrentQuantity() + ")");
        }

        StockMovementDto movementDto = new StockMovementDto();
        movementDto.setStockItemId(id);
        movementDto.setMovementType(movementType);
        movementDto.setQuantityDelta(delta);
        movementDto.setReferencePoId(referencePoId);

        StockMovement movement = stockMovementService.recordMovement(movementDto, performedBy);

        item.setCurrentQuantity(newQty);
        stockItemRepository.save(item);

        if (newQty < item.getMinimumThreshold() && Boolean.TRUE.equals(item.getAutoReorderEnabled())) {
            triggerAutoReorder(item);
        }

        return movement;
    }

    private void triggerAutoReorder(StockItem item) {
        if (item.getPreferredSupplierId() == null) return;

        Supplier supplier = supplierRepository.findById(item.getPreferredSupplierId()).orElse(null);
        if (supplier == null || supplier.getStatus() != Supplier.SupplierStatus.ACTIVE) return;

        PurchaseOrder po = new PurchaseOrder();
        po.setPoNumber("AUTO-" + UUID.randomUUID().toString().substring(0, 8));
        po.setStatus(PurchaseOrder.OrderStatus.DRAFT);
        po.setOrderedBy("SYSTEM-AUTO");
        po.setSupplier(supplier);
        po.setOrderDate(LocalDateTime.now());

        PurchaseOrder.PurchaseOrderLine line = new PurchaseOrder.PurchaseOrderLine();
        line.setStockItem(item);
        line.setOrderedQuantity(item.getReorderQuantity());
        line.setReceivedQuantity(0);
        line.setUnitPrice(item.getUnitPrice());

        po.setLines(List.of(line));
        po.setTotalAmount(item.getUnitPrice().multiply(BigDecimal.valueOf(item.getReorderQuantity())));

        purchaseOrderRepository.save(po);

        StockMovementDto reorderDto = new StockMovementDto();
        reorderDto.setStockItemId(item.getId());
        reorderDto.setMovementType("REORDER_TRIGGERED");
        reorderDto.setQuantityDelta(0);
        reorderDto.setNotes("Auto-reorder triggered (Level: " + item.getCurrentQuantity() + ")");

        stockMovementService.recordMovement(reorderDto, "SYSTEM-AUTO");
    }

    public DashboardDto getDashboardStats() {
        long totalSkus = stockItemRepository.count();
        long lowStockAlerts = stockItemRepository.countLowStockItems();
        long openPOs = purchaseOrderRepository.countByStatus(PurchaseOrder.OrderStatus.DRAFT)
                + purchaseOrderRepository.countByStatus(PurchaseOrder.OrderStatus.SUBMITTED)
                + purchaseOrderRepository.countByStatus(PurchaseOrder.OrderStatus.APPROVED);
        long activeSuppliers = supplierRepository.countByStatus(Supplier.SupplierStatus.ACTIVE);

        Map<String, Long> grouped = stockItemRepository.findAll().stream()
                .collect(Collectors.groupingBy(StockItem::getCategory, Collectors.counting()));

        List<Map<String, Object>> stockByCategory = grouped.entrySet().stream()
                .map(e -> {
                    Map<String, Object> m = new HashMap<>();
                    m.put("label", e.getKey());
                    m.put("value", e.getValue());
                    return m;
                })
                .collect(Collectors.toList());

        return new DashboardDto(totalSkus, lowStockAlerts, openPOs, activeSuppliers, stockByCategory);
    }

    public void deleteItem(Long id) {
        stockMovementService.deleteMovementsByItemId(id);
        purchaseOrderRepository.deleteLinesByStockItemId(id);
        stockItemRepository.deleteById(id);
    }
}