// // src/main/java/com/example/demo/service/AuthService.java
// package com.example.demo.service;

// import com.example.demo.dto.AuthRequestDto;
// import com.example.demo.dto.AuthResponseDto;
// import com.example.demo.entity.SystemUser;
// import com.example.demo.exception.BusinessValidationException;
// import com.example.demo.repository.SystemUserRepository;
// import com.example.demo.util.JwtService;
// import org.springframework.security.crypto.password.PasswordEncoder;
// import org.springframework.stereotype.Service;

// @Service
// public class AuthService {

//     private final SystemUserRepository systemUserRepository;
//     private final PasswordEncoder passwordEncoder;
//     private final JwtService jwtService;

//     public AuthService(SystemUserRepository systemUserRepository, PasswordEncoder passwordEncoder, JwtService jwtService) {
//         this.systemUserRepository = systemUserRepository;
//         this.passwordEncoder = passwordEncoder;
//         this.jwtService = jwtService;
//     }

//     public AuthResponseDto login(AuthRequestDto request) {
//         SystemUser user = systemUserRepository.findByUsername(request.getUsername())
//                 .orElseThrow(() -> new BusinessValidationException("Invalid username or password"));

//         if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
//             throw new BusinessValidationException("Invalid username or password");
//         }

//         String token = jwtService.generateToken(user.getUsername(), user.getRole());
//         return new AuthResponseDto(token, user.getRole(), user.getUsername());
//     }
// }
// src/main/java/com/example/demo/service/AuthService.java
package com.example.demo.service;

import com.example.demo.dto.AuthRequestDto;
import com.example.demo.dto.AuthResponseDto;
import com.example.demo.entity.SystemUser;
import com.example.demo.exception.BusinessValidationException;
import com.example.demo.repository.SystemUserRepository;
import com.example.demo.util.JwtService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    private final SystemUserRepository systemUserRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;

    public AuthService(SystemUserRepository systemUserRepository, PasswordEncoder passwordEncoder, JwtService jwtService) {
        this.systemUserRepository = systemUserRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtService = jwtService;
    }

    public AuthResponseDto login(AuthRequestDto request) {
        SystemUser user = systemUserRepository.findByUsername(request.getUsername())
                .orElseThrow(() -> new BusinessValidationException("Invalid username or password"));

        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            throw new BusinessValidationException("Invalid username or password");
        }

        String token = jwtService.generateToken(user.getUsername(), user.getRole());
        return new AuthResponseDto(token, user.getRole(), user.getUsername());
    }

    public AuthResponseDto register(AuthRequestDto request) {
        if (systemUserRepository.findByUsername(request.getUsername()).isPresent()) {
            throw new BusinessValidationException("Username already exists");
        }

        String role = request.getRole() != null ? request.getRole().toUpperCase() : "VIEWER";

        SystemUser user = new SystemUser(
                request.getUsername(),
                passwordEncoder.encode(request.getPassword()),
                role
        );
        systemUserRepository.save(user);

        String token = jwtService.generateToken(user.getUsername(), user.getRole());
        return new AuthResponseDto(token, user.getRole(), user.getUsername());
    }
}